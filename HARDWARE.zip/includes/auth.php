<?php
// includes/auth.php

// Ensure session is started and db is included
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';



// Redirect if not logged in
if (!isset($_SESSION['user']) && !isset($_SESSION['customer'])) {
    header('Location: ../login.php');
    exit();
}

// Check if the user is an admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Admin';
}

// Check if the user is an employee
function isEmployee() {
    return isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'employee';
}
?>