<footer class="bg-dark text-white text-center py-3">
    <div class="container">
        <p>&copy; 2025 Four A's Marketing. All rights reserved.</p>
    </div>
</footer>